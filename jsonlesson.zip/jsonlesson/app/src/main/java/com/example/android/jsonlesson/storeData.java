package com.example.android.jsonlesson;

import android.os.AsyncTask;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by pcs on 07-Jul-18.
 */

public class storeData extends AsyncTask<String,Void,String> {
    HttpURLConnection httpURLConnection=null;
    String data=" ";
    @Override
    public String doInBackground(String... params) {
        try {

            httpURLConnection=(HttpURLConnection)new URL(params[0]).openConnection();
            httpURLConnection.setRequestMethod("POST");

            httpURLConnection.setDoOutput(true);

            DataOutputStream wr=new DataOutputStream(httpURLConnection.getOutputStream());
            wr.writeBytes("PostData= "+params[1]);
            wr.flush();
            wr.close();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return data;
    }
}
