package com.example.android.jsonlesson;

import android.content.Context;
import android.os.AsyncTask;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DecimalFormat;

/**
 * Created by pcs on 30-Jun-18.
 */

public class fetchData extends AsyncTask<Void,Void,Void> {

    String storedData="";
    String dataParsed="";
    String singleParsed="";
String msc;

String humidity;
String pressure;
String temp;

    @Override
    protected Void doInBackground(Void... voids) {
        try {
            String st=MainActivity.et.getText().toString();

            URL url=new URL("http://api.openweathermap.org/data/2.5/weather?q="+st+"&appid=1f0c823f1feb761c3f00ff5339d5475c");
            HttpURLConnection httpURLConnection= (HttpURLConnection) url.openConnection();
            InputStream inputStream=httpURLConnection.getInputStream();
            BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream));

            String line=" ";
            while(line!=null){
                line=bufferedReader.readLine();
                storedData=storedData+line;
            }

            JSONObject jo=new JSONObject(storedData);

            JSONArray JA=jo.getJSONArray("weather");
            for (int i = 0; i < JA.length(); i++) {
                JSONObject c = JA.getJSONObject(i);
                String id = c.getString("main");
                dataParsed = dataParsed+id;

            }

            msc=jo.getString("name");
            JSONObject humidJO=jo.getJSONObject("main");
            humidity=humidJO.getString("humidity");
            System.out.println("Ishtdeep"+humidity);
            pressure=humidJO.getString("pressure");
            System.out.println(pressure);
            temp=humidJO.getString("temp");
            System.out.println(temp);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        System.out.println(msc);
        MainActivity.phenomenon.setText(dataParsed);
        MainActivity.cityName.setText(msc+ ", IN");
        MainActivity.humidity.setText("Humidity: "+humidity+"%");
        MainActivity.pressure.setText("Pressure: "+pressure+" KPa");
        Double sp=Double.parseDouble(temp)/10;
        DecimalFormat f=new DecimalFormat("##.00");
        MainActivity.systemTime.setText("Last Updated on:"+(int) System.currentTimeMillis());
        MainActivity.temp.setText(f.format(sp)+" "+(char)0x00B0+"C");
        System.out.println("Hello"+humidity);
        System.out.println("World"+pressure);
        System.out.println(temp);


    }
}
