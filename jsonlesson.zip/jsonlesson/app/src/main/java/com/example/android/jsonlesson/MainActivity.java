package com.example.android.jsonlesson;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
Button btn;
public static TextView data;



public static TextView phenomenon;
public static TextView humidity;
public static TextView cityName;
public static TextView pressure;
public static TextView temp;
public static TextView systemTime;

public static EditText et;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        systemTime=(TextView)findViewById(R.id.currentTime);

        btn=findViewById(R.id.clickme);
        data=findViewById(R.id.phenomenon);


        pressure=findViewById(R.id.pressure);
        temp=findViewById(R.id.temp);
        cityName=findViewById(R.id.cityName);
        humidity=findViewById(R.id.humidity);
        phenomenon=findViewById(R.id.phenomenon);
        et=(EditText)findViewById(R.id.editText);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetchData process=new fetchData();
                process.execute();
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();


    }
}
